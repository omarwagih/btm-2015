setwd("~/Desktop/data")
temp = list.files(pattern="*.csv")
dat = lapply(temp, function(file){
  writeLines(file)
  df = read.csv(file, header=T, stringsAsFactors=F)
  if(nrow(df) == 0) return(NULL)
  mydate = gsub(".csv|weedprices", "", file)
  mydate2 = as.Date(mydate, "%d%m%Y")
  df$date = mydate2
  
  df$HighQ = as.numeric( gsub("\\$", "", df$HighQ) )
  df$MedQ = as.numeric( gsub("\\$", "", df$MedQ) )
  df$LowQ = as.numeric( gsub("\\$", "", df$LowQ) )
  return(df)
})


all_dat = do.call(rbind, dat)

# for (i in 1:length(temp)) assign(temp[i], read.csv(temp[i]))
# 
# as.numeric(weedprices01012014.csv[,2])
# as.numeric(weedprices01012014.csv[,3])
#  test <- weedprices01012014.csv[,2] / weedprices01012014.csv[,3]

